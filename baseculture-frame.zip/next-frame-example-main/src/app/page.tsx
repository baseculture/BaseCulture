import App from "./pageClient";

export default function Home() {
  return <App />
}
